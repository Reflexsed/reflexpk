# SCRAPPER CC

This code is open and anyone can modify it to their liking. just give me one ⭐


## Requirements

These are the libraries used by this project.

```bash
  pip install Telethon
  pip install requests
  pip install random-address
  pip install names
```
    
## How to use

To run it, simply open a CMD console and go to the folder where you have the project and once inside the path run with: Python main.py




## Authors

- [@Andsses](https://github.com/Andsses?tab=repositories)
- [@x0andy](https://web.telegram.org/k/#@x0andy)


